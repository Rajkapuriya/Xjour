import ImagePlaceholder from "assets/images/image-placeholder.jpg";

export { ImagePlaceholder };
