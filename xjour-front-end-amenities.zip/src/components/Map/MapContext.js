import React from "react";
const MapContext = new React.createContext();
export default MapContext;
