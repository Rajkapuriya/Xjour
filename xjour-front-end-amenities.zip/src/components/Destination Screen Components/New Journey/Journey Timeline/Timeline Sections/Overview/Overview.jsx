import React from "react";
import "./Overview.css";

function Overview() {
  return (
    <div className="overview">
      <h3>Overiew Section</h3>
    </div>
  );
}

export default Overview;
