import React from "react";
import "./TermsAndConditions.css";

function TermsAndConditions() {
  return <div className="termsAndConditions"></div>;
}

export default TermsAndConditions;
