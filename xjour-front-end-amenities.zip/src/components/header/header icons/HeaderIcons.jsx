// import React, { useState } from "react";
// import "./HeaderIcons.css";

// function HeaderIcons({ Icon, title, active }) {
//   const [activate, setActivate] = useState(active)

//   const activeButton = () => {
//     setActivate(!activate)
//   }

//   return (
//     <div onClick={activeButton} className={`headerIcon ${activate && "headerIcon--active"}`}>
//       <Icon />
//       <p className='headerIcon__text'>{title}</p>
//     </div>




//   );
// }

// export default HeaderIcons;
