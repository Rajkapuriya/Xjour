import React from "react";
import CalenderScreen from "../../components/Calender Screen Components/CalenderScreen";
import "./Calender.css";

function Calender() {
  return (
    <div className="calender">
    <CalenderScreen />
    </div>
  );
}

export default Calender;
